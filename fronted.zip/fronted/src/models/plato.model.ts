export interface Plato {
    id: number;
    nombre: string;
    precio: number;
    descripcion: string;
}
