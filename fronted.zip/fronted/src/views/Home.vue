<template>
  <div class="home-container">

    
    <header class="hero">
      <div class="overlay"></div>
      <div class="hero-content">
        <h1 class="title">Restaurante los Bros</h1>
        <p class="subtitle">Sabores auténticos, ingredientes frescos</p>
      </div>
    </header>

    
    <section class="cards-section">
      <div class="card" @click="$router.push('/platos')">
        <img src="https://images.unsplash.com/photo-1600891964599-f61ba0e24092" alt="Platos">
        <h3>Ver Platos</h3>
      </div>

      <div class="card" @click="$router.push('/usuarios')">
        <img src="https://images.unsplash.com/photo-1529665253569-6d01c0eaf7b6" alt="Usuarios">
        <h3>Gestión de Usuarios</h3>
      </div>

      <div class="card" @click="$router.push('/pedidos')">
        <img src="https://images.unsplash.com/photo-1559056199-641a0ac8b55e" alt="Pedidos">
        <h3>Pedidos</h3>
      </div>
    </section>

  </div>
</template>

<script>
export default {
  name: "HomeView",
};
</script>

<style scoped>

.home-container {
  font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
  color: #333;
}


.hero {
  position: relative;
  height: 55vh;
  background-image: url("https://images.unsplash.com/photo-1555939594-58d7cb561ad1");
  background-size: cover;
  background-position: center;
  border-bottom: 5px solid #b83a1b;
}

.overlay {
  position: absolute;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.45);
}

.hero-content {
  position: relative;
  z-index: 2;
  text-align: center;
  top: 35%;
  color: white;
}

.title {
  font-size: 3rem;
  font-weight: bold;
}

.subtitle {
  font-size: 1.2rem;
  margin-top: 10px;
}


.cards-section {
  display: flex;
  justify-content: center;
  gap: 25px;
  padding: 40px 20px;
  flex-wrap: wrap;
}

.card {
  width: 280px;
  background: white;
  border-radius: 12px;
  overflow: hidden;
  cursor: pointer;
  transition: all 0.3s ease;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15);
}

.card img {
  width: 100%;
  height: 170px;
  object-fit: cover;
}

.card h3 {
  padding: 15px;
  text-align: center;
  font-size: 1.2rem;
  color: #b83a1b;
}

.card:hover {
  transform: translateY(-8px);
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.25);
}
</style>
