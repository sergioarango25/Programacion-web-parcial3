<script setup>
import { ref, onMounted } from 'vue';
import { getPlatos, createPlato, deletePlato } from '../services/platosService';

const platos = ref([]);
const nuevoPlato = ref({ nombre: '', descripcion: '', precio: 0 });

const cargarPlatos = async () => {
  const res = await getPlatos();
  platos.value = res.data;
};

const agregarPlato = async () => {
  await createPlato(nuevoPlato.value);
  nuevoPlato.value = { nombre: '', descripcion: '', precio: 0 };
  cargarPlatos();
};

const eliminarPlato = async (id) => {
  await deletePlato(id);
  cargarPlatos();
};

onMounted(cargarPlatos);
</script>

<template>
  <div class="platos-container">
    <h1 class="title">Gestión de Platos</h1>

    <!-- Formulario -->
    <div class="form-card">
      <h2>Agregar Plato</h2>

      <div class="form-group">
        <label>Nombre</label>
        <input v-model="nuevoPlato.nombre" placeholder="Nombre del plato" />
      </div>

      <div class="form-group">
        <label>Descripción</label>
        <input v-model="nuevoPlato.descripcion" placeholder="Descripción" />
      </div>

      <div class="form-group">
        <label>Precio</label>
        <input
          v-model.number="nuevoPlato.precio"
          type="number"
          min="0"
          placeholder="Precio"
        />
      </div>

      <button class="btn-create" @click="agregarPlato">Agregar Plato</button>
    </div>

    <!-- Lista -->
    <h2 class="subtitle">Listado de Platos</h2>

    <ul class="plato-list">
      <li v-for="plato in platos" :key="plato.id" class="plato-item">
        <div class="plato-info">
          <p><strong>Nombre:</strong> {{ plato.nombre }}</p>
          <p><strong>Descripción:</strong> {{ plato.descripcion }}</p>
          <p><strong>Precio:</strong> ${{ plato.precio }}</p>
        </div>

        <button class="btn-delete" @click="eliminarPlato(plato.id)">
          Eliminar
        </button>
      </li>
    </ul>

  </div>
</template>

<style scoped>
.platos-container {
  max-width: 850px;
  margin: auto;
  padding: 25px;
  font-family: "Segoe UI", sans-serif;
}

.title {
  text-align: center;
  font-size: 2.3rem;
  color: #b83a1b;
  margin-bottom: 25px;
}

.subtitle {
  margin-top: 40px;
  color: #444;
}

.form-card {
  background: white;
  padding: 20px 25px;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.12);
  margin-bottom: 30px;
}

.form-card h2 {
  color: #b83a1b;
  margin-bottom: 15px;
}

.form-group {
  margin-bottom: 15px;
}

label {
  font-weight: bold;
  color: #444;
}

input {
  width: 100%;
  padding: 8px;
  border: 1px solid #bbb;
  border-radius: 5px;
  margin-top: 5px;
}

.btn-create {
  margin-top: 10px;
  padding: 10px 18px;
  background-color: #b83a1b;
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  width: 100%;
  font-size: 1rem;
  transition: 0.3s;
}

.btn-create:hover {
  background-color: #952f17;
}

/* LISTA */
.plato-list {
  list-style: none;
  padding: 0;
}

.plato-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: white;
  border-radius: 10px;
  padding: 15px 20px;
  margin-bottom: 15px;
  box-shadow: 0 3px 8px rgba(0,0,0,0.1);
}

.plato-info p {
  margin: 3px 0;
}

.btn-delete {
  padding: 8px 15px;
  background-color: #e63939;
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  transition: 0.2s;
}

.btn-delete:hover {
  background-color: #b02727;
}
</style>
