<script setup>
import { ref, onMounted } from 'vue';
import { getPedidos, createPedido, deletePedido } from '../services/pedidosService';

const pedidos = ref([]);
const nuevoPedido = ref({ usuarioId: '', platoId: '', cantidad: 1 });

const cargarPedidos = async () => {
  const res = await getPedidos();
  pedidos.value = res.data;
};

const agregarPedido = async () => {
  await createPedido(nuevoPedido.value);
  nuevoPedido.value = { usuarioId: '', platoId: '', cantidad: 1 };
  cargarPedidos();
};

const eliminarPedido = async (id) => {
  await deletePedido(id);
  cargarPedidos();
};

onMounted(cargarPedidos);
</script>

<template>
  <div class="pedidos-container">
    <h1 class="title">Gestión de Pedidos</h1>

    <!-- Formulario -->
    <div class="form-card">
      <h2>Crear Pedido</h2>

      <div class="form-group">
        <label>ID Usuario</label>
        <input v-model="nuevoPedido.usuarioId" placeholder="ID Usuario" />
      </div>

      <div class="form-group">
        <label>ID Plato</label>
        <input v-model="nuevoPedido.platoId" placeholder="ID Plato" />
      </div>

      <div class="form-group">
        <label>Cantidad</label>
        <input v-model="nuevoPedido.cantidad" type="number" min="1" />
      </div>

      <button class="btn-create" @click="agregarPedido">Agregar Pedido</button>
    </div>

    <h2 class="subtitle">Listado de Pedidos</h2>

    <!-- Lista -->
    <ul class="pedido-list">
      <li v-for="pedido in pedidos" :key="pedido.id" class="pedido-item">
        <div class="pedido-info">
          <p><strong>Usuario:</strong> {{ pedido.usuarioId }}</p>
          <p><strong>Plato:</strong> {{ pedido.platoId }}</p>
          <p><strong>Cantidad:</strong> {{ pedido.cantidad }}</p>
          <p><strong>Total:</strong> ${{ pedido.total }}</p>
        </div>

        <button class="btn-delete" @click="eliminarPedido(pedido.id)">
          Eliminar
        </button>
      </li>
    </ul>

  </div>
</template>

<style scoped>
.pedidos-container {
  max-width: 850px;
  margin: auto;
  padding: 25px;
  font-family: "Segoe UI", sans-serif;
}

.title {
  text-align: center;
  font-size: 2.3rem;
  color: #b83a1b;
  margin-bottom: 25px;
}

.subtitle {
  margin-top: 40px;
  color: #444;
}

.form-card {
  background: white;
  padding: 20px 25px;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.12);
  margin-bottom: 30px;
}

.form-card h2 {
  color: #b83a1b;
  margin-bottom: 15px;
}

.form-group {
  margin-bottom: 15px;
}

label {
  font-weight: bold;
  color: #444;
}

input {
  width: 100%;
  padding: 8px;
  border: 1px solid #bbb;
  border-radius: 5px;
  margin-top: 5px;
}

.btn-create {
  margin-top: 10px;
  padding: 10px 18px;
  background-color: #b83a1b;
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  width: 100%;
  font-size: 1rem;
  transition: 0.3s;
}

.btn-create:hover {
  background-color: #952f17;
}

/* LISTA */
.pedido-list {
  list-style: none;
  padding: 0;
}

.pedido-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: white;
  border-radius: 10px;
  padding: 15px 20px;
  margin-bottom: 15px;
  box-shadow: 0 3px 8px rgba(0,0,0,0.1);
}

.pedido-info p {
  margin: 3px 0;
}

.btn-delete {
  padding: 8px 15px;
  background-color: #e63939;
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  transition: 0.2s;
}

.btn-delete:hover {
  background-color: #b02727;
}
</style>
