<script setup>
import { ref, onMounted } from 'vue';
import { getUsuarios, createUsuario, deleteUsuario } from '../services/usuariosService';

const usuarios = ref([]);
const nuevoUsuario = ref({ nombre: '', email: '' });

const cargarUsuarios = async () => {
  const res = await getUsuarios();
  usuarios.value = res.data;
};

const agregarUsuario = async () => {
  await createUsuario(nuevoUsuario.value);
  nuevoUsuario.value = { nombre: '', email: '' };
  cargarUsuarios();
};

const eliminarUsuario = async (id) => {
  await deleteUsuario(id);
  cargarUsuarios();
};

onMounted(cargarUsuarios);
</script>

<template>
  <div class="usuarios-container">
    <h1 class="title">Gestión de Usuarios</h1>

    <!-- Formulario -->
    <div class="form-card">
      <h2>Agregar Usuario</h2>

      <div class="form-group">
        <label>Nombre</label>
        <input v-model="nuevoUsuario.nombre" placeholder="Nombre del usuario" />
      </div>

      <div class="form-group">
        <label>Email</label>
        <input v-model="nuevoUsuario.email" placeholder="correo@ejemplo.com" />
      </div>

      <button class="btn-create" @click="agregarUsuario">Agregar Usuario</button>
    </div>

    <!-- Lista -->
    <h2 class="subtitle">Listado de Usuarios</h2>

    <ul class="usuario-list">
      <li v-for="usuario in usuarios" :key="usuario.id" class="usuario-item">
        <div class="usuario-info">
          <p><strong>Nombre:</strong> {{ usuario.nombre }}</p>
          <p><strong>Email:</strong> {{ usuario.email }}</p>
        </div>

        <button class="btn-delete" @click="eliminarUsuario(usuario.id)">
          Eliminar
        </button>
      </li>
    </ul>
  </div>
</template>

<style scoped>
.usuarios-container {
  max-width: 850px;
  margin: auto;
  padding: 25px;
  font-family: "Segoe UI", sans-serif;
}

.title {
  text-align: center;
  font-size: 2.3rem;
  color: #b83a1b;
  margin-bottom: 25px;
}

.subtitle {
  margin-top: 40px;
  color: #444;
}

.form-card {
  background: white;
  padding: 20px 25px;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.12);
  margin-bottom: 30px;
}

.form-card h2 {
  color: #b83a1b;
  margin-bottom: 15px;
}

.form-group {
  margin-bottom: 15px;
}

label {
  font-weight: bold;
  color: #444;
}

input {
  width: 100%;
  padding: 8px;
  border: 1px solid #bbb;
  border-radius: 5px;
  margin-top: 5px;
}

.btn-create {
  margin-top: 10px;
  padding: 10px 18px;
  background-color: #b83a1b;
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  width: 100%;
  font-size: 1rem;
  transition: 0.3s;
}

.btn-create:hover {
  background-color: #952f17;
}

/* LISTA */
.usuario-list {
  list-style: none;
  padding: 0;
}

.usuario-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: white;
  border-radius: 10px;
  padding: 15px 20px;
  margin-bottom: 15px;
  box-shadow: 0 3px 8px rgba(0,0,0,0.1);
}

.usuario-info p {
  margin: 3px 0;
}

.btn-delete {
  padding: 8px 15px;
  background-color: #e63939;
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  transition: 0.2s;
}

.btn-delete:hover {
  background-color: #b02727;
}
</style>
